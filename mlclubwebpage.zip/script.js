// Accessible mobile menu toggle
(() => {
  const btn = document.querySelector('.menu-btn');
  const nav = document.querySelector('.nav-links');
  if (!btn || !nav) return;

  // Ensure ARIA hookups
  nav.id = nav.id || 'primary-nav';
  btn.setAttribute('aria-controls', nav.id);
  btn.setAttribute('aria-expanded', 'false');

  const setExpanded = (expanded) => {
    btn.setAttribute('aria-expanded', String(expanded));
    nav.classList.toggle('open', expanded);
  };

  btn.addEventListener('click', () => {
    const expanded = btn.getAttribute('aria-expanded') === 'true';
    setExpanded(!expanded);
  });

  // Close on Escape when open
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && btn.getAttribute('aria-expanded') === 'true') {
      setExpanded(false);
      btn.focus();
    }
  });
})();

// Form enhancement for #join form
(() => {
  const form = document.querySelector('#join form');
  if (!form) return;

  // Add names/ids that the PHP expects if missing
  const nameInput = form.querySelector('input[type="text"]:not([name])') || form.querySelector('input[name="name"]');
  const facultyInput = form.querySelector('input[placeholder*="Faculty"]') || form.querySelector('input[name="faculty_no"]');
  const emailInput = form.querySelector('input[type="email"]');
  const interestSelect = form.querySelector('select');
  const msgTextarea = form.querySelector('textarea');

  if (nameInput) { nameInput.name = nameInput.name || 'name'; nameInput.id = nameInput.id || 'name'; nameInput.required = true; }
  if (facultyInput) { facultyInput.name = facultyInput.name || 'faculty_no'; facultyInput.id = facultyInput.id || 'faculty_no'; facultyInput.required = true; }
  if (emailInput) { emailInput.name = emailInput.name || 'email'; emailInput.id = emailInput.id || 'email'; emailInput.required = true; emailInput.setAttribute('autocomplete', 'email'); }
  if (interestSelect) { interestSelect.name = interestSelect.name || 'interest'; interestSelect.id = interestSelect.id || 'interest'; interestSelect.required = true; }
  if (msgTextarea) { msgTextarea.name = msgTextarea.name || 'message'; msgTextarea.id = msgTextarea.id || 'message'; msgTextarea.required = true; }

  // Status element
  let status = document.createElement('div');
  status.setAttribute('role', 'status');
  status.style.marginTop = '10px';
  status.style.color = '#23455d';
  form.appendChild(status);

  const showStatus = (msg, ok) => {
    status.textContent = msg;
    status.style.color = ok ? '#1b5e20' : '#a90909';
  };

  // Client-side checks leveraging HTML5 + custom messages
  const isValid = () => {
    if (nameInput && !nameInput.value.trim()) { nameInput.focus(); showStatus('Please enter full name.', false); return false; }
    if (facultyInput && !facultyInput.value.trim()) { facultyInput.focus(); showStatus('Please enter faculty number.', false); return false; }
    if (emailInput && !emailInput.validity.valid) { emailInput.focus(); showStatus('Please enter a valid email address.', false); return false; }
    if (interestSelect && !interestSelect.value) { interestSelect.focus(); showStatus('Please select an interest.', false); return false; }
    if (msgTextarea && !msgTextarea.value.trim()) { msgTextarea.focus(); showStatus('Please add a short message.', false); return false; }
    return true;
  };

  form.addEventListener('submit', async (e) => {
    // Let standard POST happen if no PHP endpoint configured
    if (!isValid()) { e.preventDefault(); return; }

    // Progressive enhancement: AJAX submit to PHP for nicer UX
    const action = form.getAttribute('action') || 'join.php';
    const method = (form.getAttribute('method') || 'post').toUpperCase();

    // Only intercept if pointing to join.php
    if (!/join\.php(\?|$)/i.test(action)) return;

    e.preventDefault();
    showStatus('Sending request...', true);

    try {
      const resp = await fetch(action, {
        method,
        headers: { 'Accept': 'application/json' },
        body: new FormData(form)
      });
      const isJson = resp.headers.get('content-type')?.includes('application/json');
      const data = isJson ? await resp.json() : null;

      if (resp.ok && data?.ok) {
        showStatus('Join request sent successfully. Check email for confirmation if provided.', true);
        form.reset();
      } else {
        const msg = data?.error || 'Could not send request. Try again later.';
        showStatus(msg, false);
      }
    } catch {
      showStatus('Network error. Please try again.', false);
    }
  });
})();
